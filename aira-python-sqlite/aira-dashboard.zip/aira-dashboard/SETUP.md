# Aira Godmode Dashboard — setup

## Before you deploy (read this first)

This was built against the schema your context doc *describes* for the bot's
sqlite/Mongo-shim tables — `_id TEXT PRIMARY KEY, doc TEXT` (a JSON blob) for
`users`, and the assumption that `groups` / `meta` follow the same shape
since they go through the same shim client. **I did not have your real
`sqlite_shim.py` or `aira_bot.py`, only the exported chat transcript** — so
this is a best-effort rebuild of what was described, not code copied from
your original files.

The dashboard checks itself: open it and look at the top of any page. If the
real tables don't match, a red banner lists exactly what's wrong instead of
silently showing empty data. If you see that banner, the only files you
should need to touch are the `TABLE_*` / `FIELD_*` constants at the top of
`db_adapter.py` — everything else (auth, routes, UI) is independent of the
exact schema.

**Redeem codes** are the biggest unknown: if your bot already has its own
redeem-code table or command, point `REDEEM_TABLE` in `db_adapter.py` at it
and adjust the field names — otherwise codes created here live in their own
table and your bot's existing `/redeem` handler (if any) won't recognize
them yet.

**Owner commands** are auto-detected by scanning your bot's `.py` files for
command handlers near an owner/admin ID check — this is a starting point to
verify, not a guaranteed-complete list. For something reliable, create
`owner_commands.json` next to your bot code:
```json
[
  {"name": "/broadcast", "usage": "/broadcast <text>", "description": "Send a message to every user."}
]
```

## 1. Install

```bash
cd /home/azureuser/aira-bot/aira-python-sqlite
mkdir -p aira-dashboard && cd aira-dashboard
# copy dashboard_server.py, auth.py, db_adapter.py, bot_ops.py, templates/, static/,
# dashboard_config.json, requirements.txt here
python3 -m venv venv
./venv/bin/pip install -r requirements.txt
```

## 2. Environment

Reuse the bot's own `.env` (for `BOT_TOKEN`), plus a few dashboard-specific
vars. Either export these in the systemd unit (see below, already set up
for the default paths) or add them to the `.env`:

| Variable | Default | Purpose |
|---|---|---|
| `AIRA_BOT_DIR` | current dir | Bot's folder — file browser is sandboxed to this |
| `AIRA_DB_PATH` | `aira.db` | Path to the bot's sqlite database |
| `AIRA_SERVICE_NAME` | `aira-bot` | systemd unit name the dashboard controls |
| `BOT_TOKEN` | — | Same Telegram token the bot uses, needed for Announce |
| `AIRA_DASHBOARD_CONFIG` | `dashboard_config.json` | Where the two accounts + password hashes live |
| `AIRA_AUTO_RESTART` | `1` | Set to `0` to stop the bot auto-restarting after a user-data edit |

## 3. Passwordless sudo (only for bot control, nothing else)

The dashboard needs to run `systemctl start/stop/restart` on the bot's unit
without a password prompt. Grant **exactly that**, nothing wider:

```bash
sudo visudo -f /etc/sudoers.d/aira-dashboard
```
```
azureuser ALL=(root) NOPASSWD: /usr/bin/systemctl start aira-bot, /usr/bin/systemctl stop aira-bot, /usr/bin/systemctl restart aira-bot
```
Confirm the real path to `systemctl` with `which systemctl` first — some
distros put it at `/bin/systemctl` instead. Don't use a wildcard like
`systemctl *` here; it would let the dashboard user run *any* systemctl
command as root, not just start/stop/restart on this one unit.

Log tailing uses `journalctl -u aira-bot` — if that needs elevated
permissions on your VM, either add the dashboard's user to the `systemd-journal`
group (`sudo usermod -aG systemd-journal azureuser`, then log out/in) instead
of touching sudoers again.

## 4. Reaching it: SSH tunnel (default, safer) vs exposing it directly

The dashboard binds to `127.0.0.1:8420` only — it is not reachable from the
internet by default. Two ways to actually open it in a browser:

**SSH tunnel (recommended):**
```bash
ssh -L 8420:localhost:8420 azureuser@<VM_IP>
```
then open `http://localhost:8420` on your own machine. Nothing about this
dashboard is exposed publicly; only people who can already SSH into the VM
can reach it. This is the safer default because the two accounts protect
*who* can use the dashboard, but the SSH tunnel additionally protects
*whether the login page is even reachable* to begin with.

**Cloudflare tunnel / direct exposure (if you want it reachable without SSH):**
If you already run a Cloudflare tunnel for the bot's webhook, you can add a
second hostname pointing at `127.0.0.1:8420`. If you do this:
- Put it behind Cloudflare Access (or at minimum a Cloudflare WAF rule)
  in addition to the dashboard's own login — two accounts and a login form
  is not enough protection for something with full file-edit and bot-control
  access sitting directly on the internet.
- Rotate the two passwords in `dashboard_config.json` immediately if you
  ever suspect the tunnel hostname leaked.

## 5. Run it

Manually, to check it boots:
```bash
./venv/bin/uvicorn dashboard_server:app --host 127.0.0.1 --port 8420
```

As a service — copy `aira-dashboard.service` to `/etc/systemd/system/`,
edit the paths inside if yours differ, then:
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now aira-dashboard
```

## 6. First login

Open the dashboard, sign in as `vyash` / `iluvss` or `moonlight` / `himani`,
answer the Ghevar oath honestly, and change both passwords from Settings
the first time you're in — `dashboard_config.json` ships with the passwords
from the original brief so the two of you can get in immediately, but you
should not leave them as-is on a machine anyone else can reach.

## What I could not verify (be aware before relying on this)

- **Schema shape** for `users`/`groups`/`meta` — protected by the schema
  banner, but the banner only catches things I thought to check for.
- **Analytics fields** (`joined_at`, `last_seen`) — if your bot's user docs
  use different key names, "new today" / "active today" will read 0 even
  with real users. Adjust the `FIELD_*` constants in `db_adapter.py`.
- **Redeem code format** your bot's own handler (if one exists) expects —
  see the "Redeem codes" note above.
- **Owner command list** — auto-detected, not authoritative.
- End-to-end request flow (login → verify → dashboard → each API route) was
  exercised against a small seeded fake database and the file
  browser/editor was tested with a scratch file, all in this sandbox — not
  against your real `aira.db` or your real bot process, since neither was
  available here.
